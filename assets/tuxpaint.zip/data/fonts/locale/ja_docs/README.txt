README.txt for "tuxpaint-ttf-japanese-minimal"
Japanese TrueType Font (TTF) for Tux Paint (includes only required chars.)

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

August 12, 2006 - August 12, 2006


This font is required to run Tux Paint in Japanese.
(e.g., with the "--lang japanese" option)

This font contains only the characters needed to display the strings
found in Tux Paint.

This is a custumized subset of Sazanami-Gothic.ttf for TuxPaint.
Difference between original are, 

  a) Bitmap data which prevent correct rendering (due to SDL_ttf
     bug) are removed.
  b) All Kanji data not used in TuxPaint are removed.

Contributed by TOYAMA Shin-ichi <shin1@wmail.plala.or.jp>

