README.txt for "tuxpaint-ttf-thai"
Thai TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

July 14, 2005 - July 14, 2005


This font is required to run Tux Paint in Thai.
(e.g., with the "--lang thai" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/locale/ directory.

