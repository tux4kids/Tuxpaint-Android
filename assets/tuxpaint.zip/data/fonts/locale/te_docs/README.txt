README.txt for "tuxpaint-ttf-telugu"
Telugu TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.tuxpaint.org/

April 24, 2007 - April 24, 2007


This font is required to run Tux Paint in Telugu
(e.g., with the "--lang telugu" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/ directory.

