README.txt for "tuxpaint-ttf-tamil"
Tamil TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.tuxpaint.org/

December 5, 2002 - April 24, 2007


This font is required to run Tux Paint in Tamil.
(e.g., with the "--lang tamil" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/ directory.

