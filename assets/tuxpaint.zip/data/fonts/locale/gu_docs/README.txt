README.txt for "tuxpaint-ttf-gujarati"
Hindi TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.tuxpaint.org/

October 12, 2006 - October 12, 2006


This font is required to run Tux Paint in Gujarati.
(e.g., with the "--lang gujarati" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/locale/
directory.

