README.txt for "tuxpaint-ttf-hindi"
Hindi TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

June 11, 2004 - June 19, 2004


This font is required to run Tux Paint in Hindi.
(e.g., with the "--lang hindi" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/locale/
directory.

